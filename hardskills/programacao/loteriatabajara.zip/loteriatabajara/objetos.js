class Objeto 
{
    constructor (posX, posY){
        this.positionX = posX;
        this.positionY = posY;
    }
    positionX;
    positionY;
}

class GameObjeto extends Objeto
{
    constructor (sprite, posX, posY, size, rot)
    {
        super(posX, posY);
        this.size = size;
        this.sprite = sprite;
        this.rotation = rot;
    }

    draw(canvas, context) {
        let hsize = this.size / 2;
        let cx = this.positionX + (canvas.width/2), cy = this.positionY + (canvas.height/2); //hsize
        //console.log("Drawing GO");
        context.translate(cx, cy);
        context.rotate((Math.PI / 180) * this.rotation);     
        context.translate(-cx, -cy);
        this.sprite.draw(context, cx, cy, this.size);
        context.translate(cx, cy);
        context.rotate((Math.PI / 180) * -this.rotation);
        context.translate(-cx, -cy); 
    }
}